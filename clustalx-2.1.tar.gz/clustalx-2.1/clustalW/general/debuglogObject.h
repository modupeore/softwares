/**
 * Author: Mark Larkin
 * 
 * Copyright (c) 2007 Des Higgins, Julie Thompson and Toby Gibson.  
 */
#ifndef DEBUGLOGOBJECT_H
#define DEBUGLOGOBJECT_H
#include "DebugLog.h"

namespace clustalw
{
// MARK Dec 12 2005
extern DebugLog* logObject;
}
#endif
