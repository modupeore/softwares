/**
 * Author: Andreas Wilm
 * 
 * Copyright (c) 2007 Des Higgins, Julie Thompson and Toby Gibson.  
 */
#ifndef STATSOBJECT_H
#define STATSOBJECT_H
#include "Stats.h"

namespace clustalw
{
   extern Stats* statsObject;
}
#endif
